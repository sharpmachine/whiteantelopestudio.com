<div class="wrap">
<h2 id="wafp_title" style="margin: 10px 0px 0px 0px; padding: 0px 0px 0px 122px; height: 64px; background: url(<?php echo WAFP_URL . "/images/affiliate_royale_logo_64.png"; ?>) no-repeat">&nbsp;&nbsp;<?php _e('Affiliates', 'affiliate-royale'); ?></h2>
<br/>
<?php require(WAFP_VIEWS_PATH . '/shared/datatable.php'); ?>
</div>