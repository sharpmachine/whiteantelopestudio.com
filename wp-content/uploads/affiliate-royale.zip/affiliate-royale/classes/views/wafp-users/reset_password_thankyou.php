<h3><?php _e('Password successfully reset', 'affiliate-royale'); ?></h3>
<p><?php _e('Your new password has been emailed to you.', 'affiliate-royale'); ?></p>