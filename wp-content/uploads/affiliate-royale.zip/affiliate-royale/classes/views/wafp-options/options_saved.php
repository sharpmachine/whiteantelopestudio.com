<div class="updated"><p><strong><?php _e('Options saved.', 'affiliate-royale'); ?></strong></p></div>
