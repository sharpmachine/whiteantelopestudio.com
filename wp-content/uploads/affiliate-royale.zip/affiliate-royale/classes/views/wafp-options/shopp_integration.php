<div class="wafp-options-pane wafp-integration-option wafp-shopp-option<?php echo $shopp_class; ?>">
  <p><strong><?php _e("Affiliate Royale automatically integrates with Shopp ... so there's no additional configuration!", 'affiliate-royale'); ?></strong></p>
</div>