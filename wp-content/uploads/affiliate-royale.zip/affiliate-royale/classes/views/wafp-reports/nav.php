<p><ul class="wafp-nav-bar">
  <li><a href="javascript:wafp_view_admin_affiliate_page('admin_affiliate_stats','current',1);"><?php _e('Stats', 'affiliate-royale'); ?></a></li>
  <li><a href="javascript:wafp_view_admin_affiliate_page('admin_affiliate_top','current',1);"><?php _e('Top Referrers', 'affiliate-royale'); ?></a></li>
  <li><a href="javascript:wafp_view_admin_affiliate_page('admin_affiliate_clicks','current',1);"><?php _e('Clicks', 'affiliate-royale'); ?></a></li>
  <li><a href="javascript:wafp_view_admin_affiliate_page('admin_affiliate_transactions','current',1);"><?php _e('Transactions', 'affiliate-royale'); ?></a></li>
  <li><a href="javascript:wafp_view_admin_affiliate_page('admin_affiliate_payments','current',1);"><?php _e('Pay Affiliates', 'affiliate-royale'); ?></a></li>
</ul></p>