<p><?php _e('Only affiliates can access this page. If you would like to become an affiliate, please click the button below:', 'affiliate-royale'); ?></p>
<form name="become_affiliate_form" action="" method="post">
<input type="submit" name="become_affiliate_submit" value="<?php _e('Become an Affiliate', 'affiliate-royale'); ?>" />
</form>
