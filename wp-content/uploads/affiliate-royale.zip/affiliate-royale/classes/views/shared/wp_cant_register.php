<?php global $wafp_blogurl; ?>
<div class="error" style="padding-top: 5px; padding-bottom: 5px;"><?php printf(__('Your WordPress registration settings do not currently allow user registrations.. Go to the %s to enable registrations.', 'affiliate-royale'), '<a href="'.$wafp_blogurl.'/wp-admin/options-general.php">'.__('General Wordpress Settings Page', 'affiliate-royale').'</a>'); ?></div>
