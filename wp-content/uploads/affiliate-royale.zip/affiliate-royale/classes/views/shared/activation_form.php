<div class="wrap">
<h2 id="wafp_title" style="margin: 10px 0px 0px 0px; padding: 0px 0px 0px 122px; height: 64px; background: url(<?php echo WAFP_URL . "/images/affiliate_royale_logo_64.png"; ?>) no-repeat">&nbsp;&nbsp;<?php _e('Activate', 'affiliate-royale'); ?></h2>
<p class="description"><?php _e('Enter the username and password that was emailed to you when you purchased Affiliate Royale. If you purchased Affiliate Royale and didn\'t get a username and password <a href="http://affiliateroyale.com/contact">contact us</a> immediately so you can get your Affiliate Program up and running today!', 'affiliate-royale'); ?></p>
<?php $wafp_update->pro_cred_form(); ?>
</div>
